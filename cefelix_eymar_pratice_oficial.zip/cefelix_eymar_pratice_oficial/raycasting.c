/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycasting.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cefelix <cefelix@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/18 18:40:19 by pcapalan          #+#    #+#             */
/*   Updated: 2025/09/20 17:00:04 by cefelix          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

static void get_deltaDist(t_cub *game)
{
	if (game->rayDir.x == 0)
		game->deltaDist.x = 1e30;
	else
		game->deltaDist.x = fabs(1 / game->rayDir.x);
	if (game->rayDir.y == 0)
		game->deltaDist.y = 1e30;
	else
		game->deltaDist.y = fabs(1 / game->rayDir.y);
}

static void get_toSideDist(t_cub *game)
{
	if (game->rayDir.x < 0)
	{
		game->sideDist.x = (game->pos.x - game->mapPos.x) * game->deltaDist.x;
		game->stepX = -1;
	}
	else
	{
		game->sideDist.x = (game->mapPos.x + 1.0 - game->pos.x) * game->deltaDist.x;
		game->stepX = 1;
	}
	if (game->rayDir.y < 0)
	{
		game->sideDist.y = (game->pos.y - game->mapPos.y) * game->deltaDist.y;
		game->stepY = -1;
	}
	else
	{
		game->sideDist.y = (game->mapPos.y + 1.0 - game->pos.y) * game->deltaDist.y;
		game->stepY = 1;
	}
}

static void dda_algoritm(t_cub *game)
{
	game->hit = false;
	while (game->hit == false)
	{
		if (game->sideDist.x < game->sideDist.y)
		{
			game->sideDist.x += game->deltaDist.x;
			game->mapPos.x += game->stepX;
			game->hitSide = 0;
		}
		else
		{
			game->sideDist.y += game->deltaDist.y;
			game->mapPos.y += game->stepY;
			game->hitSide = 1;
		}
		if (game->map.map[game->mapPos.y][game->mapPos.x] > '0')
			game->hit = true;
	}
}

static void get_perpendDist(t_cub *game)
{
	if (game->hitSide == 0)
	{
		game->perpDist = (game->mapPos.x - game->pos.x + ((1 - game->stepX) / 2)) / game->rayDir.x;
		if (game->rayDir.x < 0)
			game->cur_texture = &game->texPos.east;
		else
			game->cur_texture = &game->texPos.west;
	}
	else
	{
		game->perpDist = (game->mapPos.y - game->pos.y + ((1 - game->stepY) / 2)) / game->rayDir.y;
		if (game->rayDir.y < 0)
			game->cur_texture = &game->texPos.north;
		else
			game->cur_texture = &game->texPos.south;
	}
	
	// Prevenir valores extremamente pequenos que podem causar distorção
	if (game->perpDist < 0.001f)
		game->perpDist = 0.001f;
}

void raycasting(t_cub *game)
{
	int pixel;

	pixel = 0;
	while (pixel < SWIDTH)
	{
		game->mult = 2 * pixel / (float)SWIDTH - 1;
		game->camaraPixel = multVector(game->camaraPlane, game->mult);
		game->rayDir = sumVector(game->dir, game->camaraPixel);
		game->mapPos = (t_pnt){floor(game->pos.x), floor(game->pos.y)};

		get_deltaDist(game);
		get_toSideDist(game);
		dda_algoritm(game);
		get_perpendDist(game);

		game->wallLineSize = (int)(SHEIGTH / game->perpDist);
		int start = -game->wallLineSize / 2 + SHEIGTH / 2;
		if (start < 0)
			start = 0;
		int end = game->wallLineSize / 2 + SHEIGTH / 2;
		if (end >= SHEIGTH)
			end = SHEIGTH - 1;
		
		line(game, pixel, start, end);
		pixel++;
	}
}
