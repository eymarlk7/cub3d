#include "cub3d.h"

void ft_mlx_pixel_put(t_img *img, int x, int y, int color)
{
    char *dst;
    if (x < 0 || x >= SWIDTH || y < 0 || y >= SHEIGTH)
        return;
    dst = img->addr + (y * img->size_line + x * (img->bits_pp / 8));
    *(unsigned int *)dst = color;
}

unsigned int get_texture_color(t_texInfo *tex, int x, int y)
{
    int bpp;
    int offset;
    char *pixel;
    unsigned int color;

    // Verificações de segurança
    if (!tex || !tex->addr || !tex->img)
        return 0x000000; // fallback preto ao invés de rosa

    // Garantir que as coordenadas estão dentro dos limites
    if (x < 0) x = 0;
    if (x >= tex->width) x = tex->width - 1;
    if (y < 0) y = 0;
    if (y >= tex->heigth) y = tex->heigth - 1;

    bpp = tex->bits_pp / 8;
    offset = (y * tex->size_line) + (x * bpp);
    
    // Verificação mais flexível do offset
    if (offset < 0 || offset >= (tex->heigth * tex->size_line))
        return 0x000000; // fallback preto
        
    pixel = tex->addr + offset;

    if (bpp == 4) // 32 bits
        color = *(unsigned int *)pixel;
    else if (bpp == 3) // 24 bits
        color = (pixel[2] << 16) | (pixel[1] << 8) | pixel[0];
    else if (bpp == 2) // 16 bits 
        color = *(unsigned short *)pixel;
    else if (bpp == 1) // 8 bits
        color = *(unsigned char *)pixel;
    else
        color = 0x000000; // fallback preto

    return (color);
}


void background(t_cub *game)
{
    int startX;
    int startY;

    startY = 0;
    while (startY < SHEIGTH)
    {
        startX = 0;
        while (startX < SWIDTH)
        {
            if (startY <= SHEIGTH / 2)
                ft_mlx_pixel_put(&game->img, startX, startY, game->texinfo.hex_ceiling);
            else
                ft_mlx_pixel_put(&game->img, startX, startY, game->texinfo.hex_floor);
            startX++;
        }
        startY++;
    }
}

void line(t_cub *game, int pixel, int start, int end)
{
    float step;
    float wallX;
    float texPos;
    int textX;
    int lineHeigth;
    int drawStart, drawEnd;

    // Verificar se a textura atual é válida
    if (!game->cur_texture || !game->cur_texture->addr || !game->cur_texture->img)
        return;

    // Calcular a posição exata na parede onde o raio atingiu
    if (game->hitSide == 0)
        wallX = game->pos.y + game->perpDist * game->rayDir.y;
    else
        wallX = game->pos.x + game->perpDist * game->rayDir.x;
    wallX -= floor(wallX); // Manter apenas a parte fracionária

    // Garantir que wallX está no intervalo [0, 1)
    if (wallX < 0) wallX = 0;
    if (wallX >= 1) wallX = 0.999999;

    // Calcular coordenada X da textura
    textX = (int)(wallX * game->cur_texture->width);
    
    // Corrigir orientação da textura baseada na direção do raio
    if (game->hitSide == 0 && game->rayDir.x > 0)
        textX = game->cur_texture->width - textX - 1;
    if (game->hitSide == 1 && game->rayDir.y < 0)
        textX = game->cur_texture->width - textX - 1;

    // Garantir que textX está dentro dos limites
    if (textX < 0) textX = 0;
    if (textX >= game->cur_texture->width)
        textX = game->cur_texture->width - 1;

    // Calcular limites de desenho
    drawStart = start;
    drawEnd = end;
    lineHeigth = drawEnd - drawStart;

    // Evitar divisão por zero
    if (lineHeigth <= 0) return;
    
    // CORREÇÃO PRINCIPAL: Cálculo robusto para texturas próximas
    // Calcular onde a parede completa começaria e terminaria na tela
    int wallCenter = SHEIGTH / 2;
    int wallStart = wallCenter - (game->wallLineSize / 2);
    
    // Prevenir divisão por zero e valores extremos quando muito próximo
    float safeWallLineSize = fmax(1.0f, (float)game->wallLineSize);
    
    // Step baseado na altura TOTAL da parede projetada, não apenas na parte visível
    step = (float)game->cur_texture->heigth / safeWallLineSize;
    
    // Calcular posição inicial da textura de forma mais precisa
    // Considerar quantos pixels da parede estão "cortados" no topo
    float texStart = 0.0f;
    if (wallStart < 0) {
        // Parte da parede está cortada no topo
        texStart = (float)(-wallStart) * step;
    }
    
    // Posição inicial da textura para o primeiro pixel a ser desenhado
    texPos = texStart + (float)(drawStart - fmax(0, wallStart)) * step;
    
    // Garantir que texPos inicial está dentro dos limites válidos
    if (texPos < 0) texPos = 0;
    if (texPos >= game->cur_texture->heigth) texPos = game->cur_texture->heigth - 1.0f;
        
    while (drawStart <= drawEnd && drawStart < SHEIGTH)
    {
        // Garantir que textY está sempre dentro dos limites válidos
        int textY = (int)texPos;
        if (textY < 0) textY = 0;
        if (textY >= game->cur_texture->heigth) textY = game->cur_texture->heigth - 1;

        unsigned int color = get_texture_color(game->cur_texture, textX, textY);
        
        // Verificar se pixel e drawStart estão dentro dos limites
        if (pixel >= 0 && pixel < SWIDTH && drawStart >= 0)
            ft_mlx_pixel_put(&game->img, pixel, drawStart, color);
        
        drawStart++;
        
        // Avançar na textura de forma controlada
        texPos += step;
        
        // Garantir que nunca ultrapassamos os limites da textura
        if (texPos >= game->cur_texture->heigth) texPos = game->cur_texture->heigth - 1.0f;
    }
}
