#include "cub3d.h"

int key_press(int code, t_cub *game)
{
    if (code == 97)
        game->key.a = 1;
    if (code == 100)
        game->key.d = 1;
    if (code == 115)
        game->key.s = 1;
    if (code == 119)
        game->key.w = 1;
    if (code == 65307)
    {
        game->key.es = 1;
        exit(1);
    }
    if (code == 65361)
        game->key.arrow_left = 1;
    if (code == 65363)
        game->key.arrow_right = 1;
    return (0);
}

int key_release(int code, t_cub *game)
{
    if (code == 97)
        game->key.a = 0;
    if (code == 100)
        game->key.d = 0;
    if (code == 115)
        game->key.s = 0;
    if (code == 119)
        game->key.w = 0;
    if (code == 65307)
        game->key.es = 0;
    if (code == 65361)
        game->key.arrow_left = 0;
    if (code == 65363)
        game->key.arrow_right = 0;
    return (0);
}
