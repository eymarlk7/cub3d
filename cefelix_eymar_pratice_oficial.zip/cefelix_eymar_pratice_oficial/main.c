#include "cub3d.h"

int game_loop(t_cub *game)
{

	background(game);
	raycasting(game);
	mov_player(game);
	mlx_put_image_to_window(game->mlx.ptr, game->mlx.win, game->img.img_ptr, 0,
							0);
	return (0);
}

char **get_map(int fd)
{
	size_t byts;
	char *map;
	char *tmp;
	char buffer[BUFSIZ];

	map = malloc(sizeof(char));
	if (!map)
		return (NULL);
	map[0] = '\0';
	while ((byts = read(fd, buffer, sizeof(BUFSIZ))) > 0)
	{
		buffer[byts] = '\0';
		tmp = ft_strjoin(map, buffer);
		free(map);
		map = tmp;
	}
	return (ft_split(map, '\n'));
}

void init_map_info(t_map *map)
{
 	map->fd = 0;
	map->line_count = 0;
	map->path = NULL;
	map->file = NULL;
	map->height = 0;
	map->width = 0;
	map->index_end_of_map = 0;   
}

void	init_texinfo(t_texinfo *textures)
{
	textures->north = NULL;
	textures->south = NULL;
	textures->west = NULL;
	textures->east = NULL;
	textures->floor = 0;
	textures->ceiling = 0;
	textures->hex_floor = 0x0;
	textures->hex_ceiling = 0x0;
}


int	init_map(t_cub	*game,char *argv)
{
	int	fd;
	char	*file_name;

	if ((file_name = ft_strchr(argv, '.')))
	{
		if (ft_strcmp(file_name, ".cub") != 0)
			return (-1);
	}
	else
		return (ft_putstr_fd("error: extension file is wrong\n", 2), -1);
	if ((fd = open(argv, O_RDONLY)) == -1)
		return (ft_putstr_fd("error to open file\n", 2),-1);
	init_map_info(&game->map);
	init_texinfo(&game->texinfo);
	game->map.fd = fd;
	game->map.path = argv;
	game->map.file = get_map(fd);
	if (!game->map.file)
		return (ft_putstr_fd("map error\n", 2), -1);
	return (0);
}

int main(int argc, char const *argv[])
{
	t_cub *game;

	if (argc != 2)
		return (1);
	game = malloc(sizeof(t_cub));
	if (!game)
		return (1);
	if (init_map(game, (char *)argv[1]) == -1)
		return (1);

	get_file_data(game, game->map.file);
	init_game(game);

	mlx_hook(game->mlx.win, 2, 1L << 0, key_press, game);
	mlx_hook(game->mlx.win, 3, 1L << 1, key_release, game);

	mlx_loop_hook(game->mlx.ptr, game_loop, game);
	mlx_loop(game->mlx.ptr);

	return (0);
}
