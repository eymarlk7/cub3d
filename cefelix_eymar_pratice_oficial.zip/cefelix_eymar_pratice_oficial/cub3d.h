#ifndef CUB3D_H
#define CUB3D_H

#include <math.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include "libft/libft.h"
#include "minilibx-linux/mlx.h"

#define SWIDTH 800 
#define SHEIGTH 600

#define STEP 0.01
#define ROTATE 0.006

/* ----------------------------- COLORS ----------------------------- */
# define FLOOR     0x009a8c98
# define SKY       0x008eecf5
# define GREEN     0x008000
# define WHITE     0xffffff

# define RED       0xFF0000
# define BLUE      0x0000ff
# define DARKBLUE  0x00008b
# define DARKRED   0x8b0000

/* ----------------------------- ERROR MESSAGES ----------------------------- */
# define ERR_FILE_NOT_CUB     "Not a .cub file"
# define ERR_FILE_NOT_XPM     "Not an .xpm file"
# define ERR_FILE_IS_DIR      "Is a directory"
# define ERR_FLOOR_CEILING    "Invalid floor/ceiling RGB color(s)"
# define ERR_COLOR_FLOOR      "Invalid floor RGB color"
# define ERR_COLOR_CEILING    "Invalid ceiling RGB color"
# define ERR_INVALID_MAP      "Map description is either wrong or incomplete"
# define ERR_INV_LETTER       "Invalid character in map"
# define ERR_NUM_PLAYER       "Map has more than one player"
# define ERR_TEX_RGB_VAL      "Invalid RGB value (min: 0, max: 255)"
# define ERR_TEX_MISSING      "Missing texture(s)"
# define ERR_TEX_INVALID      "Invalid texture(s)"
# define ERR_COLOR_MISSING    "Missing color(s)"
# define ERR_MAP_MISSING      "Missing map"
# define ERR_MAP_TOO_SMALL    "Map is not at least 3 lines high"
# define ERR_MAP_NO_WALLS     "Map is not surrounded by walls"
# define ERR_MAP_LAST         "Map is not the last element in file"
# define ERR_PLAYER_POS       "Invalid player position"
# define ERR_PLAYER_DIR       "Map has no player position (expected N, S, E or W)"
# define ERR_MALLOC           "Could not allocate memory"
# define ERR_MLX_START        "Could not start mlx"
# define ERR_MLX_WIN          "Could not create mlx window"
# define ERR_MLX_IMG          "Could not create mlx image"

enum e_output
{
	SUCCESS = 0,
	FAILURE = 1,
	ERR     = 2,
	BREAK   = 3,
	CONTINUE = 4
};

typedef struct  s_point
{
    int x;
    int y;
}   t_pnt;

typedef struct  s_vector
{
    float   x;
    float   y;
}   t_vec;

typedef struct s_mlx
{
    void    *ptr;
    void    *win;
}   t_mlx;

typedef struct s_img
{   
    int     color;
    
    int     bits_pp;
    int     size_line;
    int     endian;

    char    *addr;
    void    *img_ptr; 
}   t_img;

typedef struct s_keys
{
    int w;
    int s;
    int a;
    int d;
    int es;
    int arrow_left;
    int arrow_right;
}   t_key;

typedef struct s_tex_info
{
    int     width;
    int     heigth;
    int     endian;
    int     bits_pp;
    int     size_line;

    char    *addr;
    void    *img;
}   t_texInfo;

typedef struct s_txtures
{
    t_texInfo   east;
    t_texInfo   west;
    t_texInfo   north;
    t_texInfo   south;
}   t_tex;

typedef struct s_texinfo
{
    char    *north;
    char    *south;
    char    *east;
    char    *west;
    int				*floor;
	int				*ceiling;
	unsigned long	hex_floor;
	unsigned long	hex_ceiling;
}   t_texinfo;

typedef struct s_map
{
	int		fd;
	int		line_count;
	char	*path;
	char	**file;
	int		height;
	int		width;
	int		index_end_of_map;
	char	**map;
}	t_map;

typedef struct s_cub3d
{
    t_vec   pos;
    t_vec   dir;
    t_vec   rayDir;
    t_vec   sideDist;
    t_vec   deltaDist;
    t_vec   camaraPlane;
    t_vec   camaraPixel;

    t_pnt   mapPos;

    int     hit;
    int     stepX;
    int     stepY;
    int     hitSide;
    int     wallLineSize;
    
    float   mult;
    float   perpDist;

    t_map map;
    t_mlx   mlx;
    t_img   img;
    t_key   key;
    t_tex       texPos;
    t_texInfo   texInfo;
    t_texInfo   *cur_texture;
    t_texinfo   texinfo;
}   t_cub;



/* FUNCTIONS */
void    init_game(t_cub *game);
void    background(t_cub *game);
void    mov_player(t_cub *game);
void	raycasting(t_cub *game);
void    init_textures(t_cub *game);

int     get_player_pos(t_cub *game);
int     get_player_dir(t_cub *game);
int     key_press(int code, t_cub *game);
int     key_release(int code, t_cub *game);

t_vec   copyVector(t_vec a);
t_vec   sumVector(t_vec a, t_vec b);
t_vec   multVector(t_vec a, float num);
t_vec   createVector(float x, float y);

void    line(t_cub *game, int pixel, int start, int end);
unsigned int get_texture_color(t_texInfo *tex, int x, int y);



int	get_file_data(t_cub *data, char **file);
int	init_map(t_cub	*game,char *argv);
int	err_msg(char *detail, char *str, int code);
int	err_msg_val(int detail, char *str, int code);
int	fill_color_textures(t_cub *data, t_texinfo *textures, char *line, int j);
int	create_map(t_cub *data, char **file, int i);
void	clean_all(t_cub *data);
void	free_tab(void **tab);
void	free_memory(char **matrix);
size_t	find_biggest_len(t_map *map, int i);
#endif