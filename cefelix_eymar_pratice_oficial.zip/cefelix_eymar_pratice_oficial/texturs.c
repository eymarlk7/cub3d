#include "cub3d.h"

void load_texture(t_mlx *mlx, t_texInfo *tex, char *path)
{
    tex->img = mlx_xpm_file_to_image(mlx->ptr, path,
        &tex->width, &tex->heigth);
    if (!tex->img)
    {
        ft_putstr_fd("Error to upload the file", 2);
        return ;
    }
    tex->addr = mlx_get_data_addr(tex->img, &tex->bits_pp,
        &tex->size_line, &tex->endian);
}

void    init_textures(t_cub *game)
{
    // load_texture(&game->mlx, &game->texPos.east, "./texture/east.xpm");
    // load_texture(&game->mlx, &game->texPos.west, "./texture/west.xpm");
    // load_texture(&game->mlx, &game->texPos.north, "./texture/north.xpm");
    // load_texture(&game->mlx, &game->texPos.south, "./texture/south.xpm");

    load_texture(&game->mlx, &game->texPos.east, game->texinfo.east);
    load_texture(&game->mlx, &game->texPos.west, game->texinfo.west);
    load_texture(&game->mlx, &game->texPos.north, game->texinfo.north);
    load_texture(&game->mlx, &game->texPos.south, game->texinfo.south);
}