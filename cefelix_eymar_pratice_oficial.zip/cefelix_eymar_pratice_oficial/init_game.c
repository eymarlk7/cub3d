#include "cub3d.h"

void    init_mlx(t_mlx *mlx)
{
    mlx->ptr = mlx_init();
    mlx->win = mlx_new_window(mlx->ptr, SWIDTH, SHEIGTH, "CUB3D");
}

void    init_img(t_cub *game)
{
    game->img.img_ptr = mlx_new_image(game->mlx.ptr, SWIDTH, SHEIGTH);
    game->img.addr = mlx_get_data_addr(
            game->img.img_ptr,
            &game->img.bits_pp,
            &game->img.size_line,
            &game->img.endian
    );
}

void    init_player(t_cub *game)
{
    if (get_player_pos(game) == -1 || get_player_dir(game) == -1)
        return ;
}

void    init_game(t_cub *game)
{
    init_mlx(&game->mlx);
    init_img(game);
    init_textures(game);
    init_player(game);
    game->key = (t_key){0};
}