#include "cub3d.h"

void movig_up_and_down(t_cub *game)
{
    float newPosY;
    float newPosX;
    float buffer = 0.1f; // Buffer de distância da parede

    newPosY = 0;
    newPosX = 0;
    if (game->key.w)
    {
        newPosY = game->pos.y + game->dir.y * STEP;
        newPosX = game->pos.x + game->dir.x * STEP;
        
        // Verificação com buffer - checa se a nova posição + buffer não colidirá
        if (game->map.map[(int)(newPosY + (game->dir.y > 0 ? buffer : -buffer))][(int)game->pos.x] != '1')
            game->pos.y = newPosY;
        if (game->map.map[(int)game->pos.y][(int)(newPosX + (game->dir.x > 0 ? buffer : -buffer))] != '1')
            game->pos.x = newPosX;
    }

    if (game->key.s)
    {
        newPosY = game->pos.y - game->dir.y * STEP;
        newPosX = game->pos.x - game->dir.x * STEP;
        
        // Verificação com buffer - direção oposta
        if (game->map.map[(int)(newPosY + (game->dir.y < 0 ? buffer : -buffer))][(int)game->pos.x] != '1')
            game->pos.y = newPosY;
        if (game->map.map[(int)game->pos.y][(int)(newPosX + (game->dir.x < 0 ? buffer : -buffer))] != '1')
            game->pos.x = newPosX;
    }
}

void moving_left_and_rigth(t_cub *game)
{
    float newPosX;
    float newPosY;
    float buffer = 0.1f; // Buffer de distância da parede

    newPosX = 0;
    newPosY = 0;
    if (game->key.a)
    {
        newPosY = game->pos.y - game->camaraPlane.y * STEP;
        newPosX = game->pos.x - game->camaraPlane.x * STEP;
        
        // Verificação com buffer
        if (game->map.map[(int)(newPosY + (-game->camaraPlane.y > 0 ? buffer : -buffer))][(int)game->pos.x] != '1')
            game->pos.y = newPosY;
        if (game->map.map[(int)game->pos.y][(int)(newPosX + (-game->camaraPlane.x > 0 ? buffer : -buffer))] != '1')
            game->pos.x = newPosX;
    }

    if (game->key.d)
    {
        newPosY = game->pos.y + game->camaraPlane.y * STEP;
        newPosX = game->pos.x + game->camaraPlane.x * STEP;
        
        // Verificação com buffer
        if (game->map.map[(int)(newPosY + (game->camaraPlane.y > 0 ? buffer : -buffer))][(int)game->pos.x] != '1')
            game->pos.y = newPosY;
        if (game->map.map[(int)game->pos.y][(int)(newPosX + (game->camaraPlane.x > 0 ? buffer : -buffer))] != '1')
            game->pos.x = newPosX;
    }
}

void moving_fov(t_cub *game)
{
    float newDirX;
    float newCamaraPlaneX;

    newDirX = 0;
    newCamaraPlaneX = 0;
    if (game->key.arrow_left)
    {
        newDirX = game->dir.x;
        game->dir.x = game->dir.x * cos(-ROTATE) - game->dir.y * sin(-ROTATE);
        game->dir.y = newDirX * sin(-ROTATE) + game->dir.y * cos(-ROTATE);

        newCamaraPlaneX = game->camaraPlane.x;
        game->camaraPlane.x = game->camaraPlane.x * cos(-ROTATE) - game->camaraPlane.y * sin(-ROTATE);
        game->camaraPlane.y = newCamaraPlaneX * sin(-ROTATE) + game->camaraPlane.y * cos(-ROTATE);
    }
    if (game->key.arrow_right)
    {
        newDirX = game->dir.x;
        game->dir.x = game->dir.x * cos(ROTATE) - game->dir.y * sin(ROTATE);
        game->dir.y = newDirX * sin(ROTATE) + game->dir.y * cos(ROTATE);

        newCamaraPlaneX = game->camaraPlane.x;
        game->camaraPlane.x = game->camaraPlane.x * cos(ROTATE) - game->camaraPlane.y * sin(ROTATE);
        game->camaraPlane.y = newCamaraPlaneX * sin(ROTATE) + game->camaraPlane.y * cos(ROTATE);
    }
}

void mov_player(t_cub *game)
{
    movig_up_and_down(game);
    moving_left_and_rigth(game);
    moving_fov(game);
}
