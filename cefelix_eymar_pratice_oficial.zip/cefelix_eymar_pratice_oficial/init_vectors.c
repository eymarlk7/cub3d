#include "cub3d.h"

int get_player_pos(t_cub *game)
{
        int y;
        int x;

        y = 0;
        while (game->map.map[y])
        {
                x = 0;
                while (game->map.map[y][x])
                {
                        if (game->map.map[y][x] == 'N' || game->map.map[y][x] == 'S' ||
                            game->map.map[y][x] == 'E' || game->map.map[y][x] == 'W')
                        {
                                game->pos = createVector(x + .5, y + .5);
                                return (1);
                        }
                        x++;
                }
                y++;
        }
        return (-1);
}

int get_player_dir(t_cub *game)
{
        int y;
        int x;

        y = 0;
        while (game->map.map[y])
        {
                x = 0;
                while (game->map.map[y][x])
                {
                        if (game->map.map[y][x] == 'N')
                        {
                                game->dir = createVector(0, -1);
                                game->camaraPlane = createVector(0.66, 0);
                                game->map.map[y][x] = '0';
                                return (1);
                        }
                        else if (game->map.map[y][x] == 'S')
                        {
                                game->dir = createVector(0, 1);
                                game->camaraPlane = createVector(-0.66, 0);
                                game->map.map[y][x] = '0';
                                return (1);
                        }
                        else if (game->map.map[y][x] == 'E')
                        {
                                game->dir = createVector(-1, 0);
                                game->camaraPlane = createVector(0, 0.66);
                                game->map.map[y][x] = '0';
                                return (1);
                        }
                        else if (game->map.map[y][x] == 'W')
                        {
                                game->dir = createVector(1, 0);
                                game->camaraPlane = createVector(0, -0.66);
                                game->map.map[y][x] = '0';
                                return (1);
                        }
                        x++;
                }
                y++;
        }
        return (-1);
}
