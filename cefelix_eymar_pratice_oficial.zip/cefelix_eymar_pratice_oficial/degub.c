#include "cub3d.h"

void	print(t_cub *game)
{
	printf("posX: %f\nposY: %f\n", game->pos.x, game->pos.y);
	printf("dirX: %f\ndirY: %f\n", game->dir.x, game->dir.y);
	printf("CamaraPlaneX: %f\nCamaraPlaneY: %f\n", game->camaraPlane.x,
		game->camaraPlane.y);

	printf("MapPosX: %d\nMapPosY: %d\n", game->mapPos.x, game->mapPos.y);
	printf("camaraPixelX: %f\ncamaraPixelY: %f\n", game->camaraPixel.x,
		game->camaraPixel.y);
	printf("rayDirX: %f\nrayDirY: %f\n", game->rayDir.x, game->rayDir.y);
}