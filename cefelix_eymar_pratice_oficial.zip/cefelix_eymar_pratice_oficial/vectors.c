#include "cub3d.h"

t_vec   createVector(float x, float y)
{
    return ((t_vec){x, y});
}

t_vec   sumVector(t_vec a, t_vec b)
{
    return ((t_vec){a.x + b.x, a.y + b.y});
}

t_vec   multVector(t_vec a, float num)
{
    return ((t_vec){a.x * num, a.y * num});
}

t_vec   copyVector(t_vec a)
{
    return (a);
}